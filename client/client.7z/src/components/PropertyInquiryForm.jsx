import { useState } from 'react';
import axios from 'axios';
import './PropertyInquiryForm.css';

const PropertyInquiryForm = ({ propertyId, propertyTitle, onSuccess, onCancel }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: `I'm interested in this property "${propertyTitle}" and I'd like to know more details.`
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevData => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate form
    if (!formData.message.trim()) {
      setError('Please enter a message');
      return;
    }
    
    setIsSubmitting(true);
    setError('');
    
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        throw new Error('You must be logged in to send an inquiry');
      }
      
      const response = await axios.post(
        `http://localhost:3000/api/properties/${propertyId}/inquire`,
        formData,
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );
      
      console.log('Inquiry response:', response.data);
      setSuccess(true);
      setIsSubmitting(false);
      
      if (onSuccess) {
        onSuccess(response.data);
      }
    } catch (err) {
      console.error('Error sending inquiry:', err);
      setError(err.response?.data?.error || err.message || 'Failed to send inquiry');
      setIsSubmitting(false);
    }
  };

  if (success) {
    return (
      <div className="inquiry-form-container success">
        <div className="success-message">
          <i className="success-icon">✓</i>
          <h3>Inquiry Sent!</h3>
          <p>Your message has been sent to the agent. They will contact you soon.</p>
          <button 
            onClick={() => {
              setSuccess(false);
              setFormData({
                name: '',
                email: '',
                phone: '',
                message: `I'm interested in this property "${propertyTitle}" and I'd like to know more details.`
              });
              if (onCancel) onCancel();
            }}
            className="close-button"
          >
            Close
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="inquiry-form-container">
      <div className="inquiry-form-header">
        <h3>Ask about this property</h3>
        {onCancel && (
          <button onClick={onCancel} className="close-form-button">
            ×
          </button>
        )}
      </div>
      
      <form onSubmit={handleSubmit} className="inquiry-form">
        <div className="form-row">
          <label htmlFor="name">Full name</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Enter your name"
          />
        </div>
        
        <div className="form-row">
          <label htmlFor="phone">Mobile number</label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            placeholder="+63"
          />
        </div>
        
        <div className="form-row">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Enter your email address"
          />
        </div>
        
        <div className="form-row">
          <label htmlFor="message">Message</label>
          <textarea
            id="message"
            name="message"
            value={formData.message}
            onChange={handleChange}
            rows={4}
            required
            placeholder="Enter your message to the agent"
          />
        </div>
        
        {error && <div className="error-message">{error}</div>}
        
        <div className="form-actions">
          <button 
            type="submit" 
            className="send-inquiry-button"
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Sending...' : 'Send property inquiry'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default PropertyInquiryForm; 